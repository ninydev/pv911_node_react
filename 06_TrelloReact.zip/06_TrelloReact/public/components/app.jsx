class App extends React.Component {

    render(){
        return (
            <div>
                <BoardList></BoardList>
                <LastUpdate></LastUpdate>
            </div>
        )
    }
}